@extends("layouts.app")

@section("content")
<x-HeaderContent title_page="Tags" menu="tags"/>
<livewire:tags />
@endsection