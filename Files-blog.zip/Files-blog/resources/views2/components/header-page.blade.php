<div class="page-header">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb p-0">
            {{ $slot }}
            <li class="breadcrumb-item"><a class="text-color" href="#">
                {{ $titlePage }}
            </a></li>
        </ol>
    </nav>
    <h3 class="page-title">
    </h3>
</div>