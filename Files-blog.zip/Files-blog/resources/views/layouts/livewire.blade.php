<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=.3, shrink-to-fit=no" />
    <title>{{ config('app.name', 'Blog Admin') }}</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{asset('assets/css/all.min.css')}}" />
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{asset('assets/css/adminlte.min.css')}}" />
    <link rel="stylesheet" href="{{asset('assets/css/mdb.min.css')}}" />
    <link rel="stylesheet" href="{{asset('assets/css/sweetalert.css')}}" />
    @yield("css")
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}" />
    <link rel="shortcut icon" href="assets/images/favicon.png" />
    @livewireStyles
</head>
<body>
    <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item ml-3">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
              <i class="fas fa-bars"></i></a>
          </li>
        </ul>
      </nav>
      <!-- /.navbar -->
    
      <!-- Main Sidebar Container -->
      <aside class="main-sidebar sidebar-light-primary elevation-4">
        <!-- Brand Logo -->
        <a href="index3.html" class="brand-link">
          <img src="{{asset('assets/images/samples/1280x768/1.jpg')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
          <span class="brand-text font-weight-light">AdminLTE 3</span>
        </a>
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="{{asset('assets/images/faces-clipart/pic-1.png')}}" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block">
              @if(Auth::check())
                  {{ Auth::user()->name }}
              @endif
            </a>
          </div>
        </div>
        <!-- Sidebar -->
        <div class="sidebar">
          <!-- Sidebar Menu -->
          <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
              <li class="nav-item {{ $open = Route::is('dashboard.*') ? 'menu-open' : '' }}">
                <a href="{{ route('dashboard.index') }}" class="nav-link {{ $active = Route::is('dashboard.*') ? 'active' : '' }}">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                    Dashboard
                  </p>
                </a>
              </li>
              <li class="nav-item {{ $open = Route::is('categories.*') ? 'menu-open' : '' }}">
                <a href="#" class="nav-link {{ $active = Route::is('categories.*') ? 'active' : '' }}">
                  <i class="nav-icon fa fa-folder"></i>
                  <p>
                    Categories
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="{{ route('categories.index') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>All Categories</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{ route('categories.create') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Add Category</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item {{ $open = Route::is('posts.*') ? 'menu-open' : '' }}">
                <a href="#" class="nav-link {{ $active = Route::is('posts.*') ? 'active' : '' }}">
                  <i class="nav-icon fa fa-file-alt"></i>
                  <p>
                    Posts
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="{{ route('posts.index') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>All Posts</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{ route('posts.create') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Add Post</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item {{ $open = Route::is('comments.*') ? 'menu-open' : '' }}">
                <a href="#" class="nav-link {{ $active = Route::is('comments.*') ? 'active' : '' }}">
                  <i class="nav-icon fas fa-comments"></i>
                  <p>
                    Comments
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="{{ route('comments.index') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>All Comments</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item {{ $open = Route::is('users.*') ? 'menu-open' : '' }}">
                <a href="#" class="nav-link {{ $active = Route::is('users.*') ? 'active' : '' }}">
                  <i class="nav-icon fas fa-users"></i>
                  <p>
                    Users
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="{{ route('users.index') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>All Users</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{ route('users.add') }}" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Add User</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                  <i class="nav-icon fas fa-sign-out-alt"></i>
                  <p>
                    Log out 
                  </p>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
              </li>
            </ul>
          </nav>
          <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
      </aside>
    
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            
            @livewire('tag')
            <livewire:tag /> 
          </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <footer class="main-footer">
        <strong>Copyright &copy; 2014-2020 <a href="#">Adel Mahmoud</a>.</strong>
        All rights reserved.
        <div class="float-right d-none d-sm-inline-block">
          <b>Version</b> 1.0
        </div>
      </footer>
    </div>
    
    <script src="{{asset('assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('assets/js/sweetalert.min.js')}}"></script>
    <script src="{{asset('assets/js/adminlte.js')}}"></script>
    <script src="{{asset('assets/js/script.js')}}"></script>
    @yield("js")
    @if (session('success'))
        <script>
            swal({
                text: "{{ session('success') }}",
                icon: "success",
            });
        </script>
    @endif
    
    @if (session('delete'))
        <script>
            swal({
                text: "{{ session('delete') }}",
                icon: "success",
            });
        </script>
    @endif
    
    @if (session('update'))
        <script>
            swal({
                text: "{{ session('update') }}",
                icon: "success",
            });
        </script>
    @endif
    <script>
      
       $(".formDelete").on("submit", function (e) {
            e.preventDefault();
            if (confirm("Do you want to delete?")) {
                $(this).unbind('submit').submit();
            }
        });

    </script>
    <!-- End custom js for this page -->
    @livewireScripts
</body>

</html>